#ifndef aegis128l_armcrypto_H
#define aegis128l_armcrypto_H

#include "implementations.h"

extern struct aegis128l_implementation aegis128l_armcrypto_implementation;

#endif